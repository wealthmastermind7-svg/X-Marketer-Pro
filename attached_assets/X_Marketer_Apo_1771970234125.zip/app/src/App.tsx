import { useState, useEffect } from 'react';
import { 
  Home, 
  FileText, 
  Calendar, 
  BarChart3, 
  Settings,
  Sparkles,
  TrendingUp,
  Clock,
  Zap,
  CheckCircle2,
  Bell,
  ChevronRight,
  Edit3,
  MoreHorizontal,
  Lightbulb,
  ArrowUpRight,
  Target,
  Users,
  MessageCircle,
  Bookmark
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { AreaChart, Area, XAxis, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import './App.css';

// Types
interface Draft {
  id: string;
  type: 'tweet' | 'thread' | 'strategy';
  title: string;
  content: string;
  tag: string;
  generatedAt: string;
  engagement?: number;
}

interface ScheduledPost {
  id: string;
  content: string;
  scheduledTime: string;
  type: 'tweet' | 'thread';
}

interface Trend {
  id: string;
  name: string;
  volume: string;
  growth: number;
}

// Mock Data
const drafts: Draft[] = [
  {
    id: '1',
    type: 'tweet',
    title: 'The Future of AI Marketing',
    content: 'Why brands need to pivot from static content to dynamic AI-driven narratives in 2024. The attention economy is shifting.',
    tag: 'HIGH IMPACT',
    generatedAt: '2m ago',
    engagement: 94,
  },
  {
    id: '2',
    type: 'tweet',
    title: '10x Your Reach with Zero Ad Spend',
    content: "The secret isn't more content. It's better storytelling. Here's a breakdown of the psychological triggers that work today.",
    tag: 'ENGAGEMENT HOOK',
    generatedAt: '14m ago',
    engagement: 87,
  },
  {
    id: '3',
    type: 'thread',
    title: 'The Viral Content Framework',
    content: 'A 7-step system for creating content that spreads. Based on analysis of 10,000+ viral posts.',
    tag: 'STRATEGY',
    generatedAt: '1h ago',
    engagement: 92,
  },
];

const scheduledPosts: ScheduledPost[] = [
  {
    id: '1',
    content: 'The future of AI in marketing i...',
    scheduledTime: 'Today at 11:30 AM',
    type: 'tweet',
  },
  {
    id: '2',
    content: 'Thread: 10 tools to scale your ...',
    scheduledTime: 'Today at 03:15 PM',
    type: 'thread',
  },
];

const trends: Trend[] = [
  { id: '1', name: '#AIMarketing', volume: '2.4M', growth: 24 },
  { id: '2', name: '#ContentStrategy', volume: '1.8M', growth: 18 },
  { id: '3', name: '#ViralGrowth', volume: '956K', growth: 42 },
];

const engagementData = [
  { time: '06 AM', value: 30 },
  { time: '08 AM', value: 45 },
  { time: '10 AM', value: 65 },
  { time: '12 PM', value: 85 },
  { time: '02 PM', value: 70 },
  { time: '04 PM', value: 55 },
  { time: '06 PM', value: 40 },
  { time: '08 PM', value: 60 },
  { time: '10 PM', value: 75 },
  { time: '12 AM', value: 50 },
];

const viralData = [
  { time: '00:00', value: 20 },
  { time: '06:00', value: 35 },
  { time: '12:00', value: 55 },
  { time: '18:00', value: 80 },
  { time: 'NOW', value: 95 },
];

// Components
const StatusBadge = ({ children, variant = 'live' }: { children: React.ReactNode; variant?: 'live' | 'success' | 'warning' }) => {
  const variants = {
    live: 'bg-emerald-500/15 text-emerald-400',
    success: 'bg-blue-500/15 text-blue-400',
    warning: 'bg-amber-500/15 text-amber-400',
  };
  
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${variants[variant]}`}>
      {variant === 'live' && <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse-live" />}
      {children}
    </span>
  );
};

const GlassCard = ({ children, className = '', premium = false }: { children: React.ReactNode; className?: string; premium?: boolean }) => (
  <div className={`${premium ? 'glass-card-premium' : 'glass-card'} rounded-2xl ${className}`}>
    {children}
  </div>
);

const TabButton = ({ icon: Icon, label, isActive, onClick }: { icon: any; label: string; isActive: boolean; onClick: () => void }) => (
  <button
    onClick={onClick}
    className={`flex flex-col items-center gap-1 py-2 px-4 transition-all duration-300 ${
      isActive ? 'text-gold' : 'text-muted-foreground hover:text-foreground'
    }`}
  >
    <Icon className={`w-5 h-5 transition-transform duration-300 ${isActive ? 'scale-110' : ''}`} />
    <span className="text-[10px] font-medium tracking-wide">{label}</span>
    {isActive && (
      <motion.div
        layoutId="activeTab"
        className="absolute bottom-0 w-8 h-0.5 bg-gradient-to-r from-gold to-gold-dark rounded-full"
      />
    )}
  </button>
);

// Screens
const HomeScreen = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const nextRun = new Date();
  nextRun.setHours(9, 0, 0, 0);
  if (nextRun < currentTime) nextRun.setDate(nextRun.getDate() + 1);
  
  const timeUntilNext = Math.ceil((nextRun.getTime() - currentTime.getTime()) / (1000 * 60 * 60));

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-6 pb-24"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-4">
        <div>
          <p className="text-xs font-medium text-gold tracking-widest uppercase">X Marketer AI</p>
          <h1 className="font-display text-2xl font-bold text-foreground mt-0.5">Dashboard</h1>
        </div>
        <button className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center relative">
          <Bell className="w-5 h-5 text-foreground" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-gold rounded-full" />
        </button>
      </div>

      {/* Cron Job Status Card */}
      <div className="px-5">
        <GlassCard premium className="p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <StatusBadge>Daily Automation Active</StatusBadge>
              <h2 className="font-display text-xl font-bold text-foreground mt-3">Daily X Marketer</h2>
              <p className="text-sm text-muted-foreground mt-1">Every day at 9:00 AM (Asia/Shanghai)</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-gradient-gold flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-navy" />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="bg-navy-light/50 rounded-xl p-3">
              <p className="text-xs text-muted-foreground">Next Run</p>
              <p className="text-sm font-semibold text-foreground mt-0.5">Tomorrow 9:00 AM</p>
            </div>
            <div className="bg-navy-light/50 rounded-xl p-3">
              <p className="text-xs text-muted-foreground">In</p>
              <p className="text-sm font-semibold text-gold mt-0.5">{timeUntilNext} hours</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Notifications enabled</span>
            <span className="mx-1">•</span>
            <Clock className="w-4 h-4" />
            <span>5 min timeout</span>
          </div>
        </GlassCard>
      </div>

      {/* Today's Tasks */}
      <div className="px-5">
        <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-gold" />
          What It Does Each Morning
        </h3>
        <div className="space-y-2">
          {[
            { icon: TrendingUp, text: 'Checks Twitter/X trends and viral patterns', done: true },
            { icon: BarChart3, text: 'Analyzes high-performing content types', done: true },
            { icon: FileText, text: 'Drafts 3-5 tweet/thread ideas for you', done: true },
            { icon: Clock, text: 'Suggests optimal posting times', done: false },
            { icon: Lightbulb, text: 'Provides one actionable growth tip', done: false },
          ].map((task, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center gap-3 p-3 rounded-xl bg-secondary/50"
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${task.done ? 'bg-emerald-500/20' : 'bg-muted'}`}>
                <task.icon className={`w-4 h-4 ${task.done ? 'text-emerald-400' : 'text-muted-foreground'}`} />
              </div>
              <span className={`text-sm flex-1 ${task.done ? 'text-foreground' : 'text-muted-foreground'}`}>
                {task.text}
              </span>
              {task.done && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="px-5">
        <h3 className="text-sm font-semibold text-foreground mb-3">Today's Overview</h3>
        <div className="grid grid-cols-2 gap-3">
          <GlassCard className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="w-4 h-4 text-azure" />
              <span className="text-xs text-muted-foreground">Drafts Ready</span>
            </div>
            <p className="font-display text-3xl font-bold text-foreground">5</p>
            <p className="text-xs text-emerald-400 mt-1 flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" /> +2 from yesterday
            </p>
          </GlassCard>
          <GlassCard className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-gold" />
              <span className="text-xs text-muted-foreground">Optimal Time</span>
            </div>
            <p className="font-display text-3xl font-bold text-foreground">09:42</p>
            <p className="text-xs text-muted-foreground mt-1">AM today</p>
          </GlassCard>
        </div>
      </div>
    </motion.div>
  );
};

const DraftsScreen = () => {
  const [activeTab, setActiveTab] = useState('tweets');
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-6 pb-24"
    >
      {/* Header */}
      <div className="px-5 pt-4">
        <div className="flex items-center gap-3 mb-4">
          <button className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
            <ChevronRight className="w-5 h-5 text-foreground rotate-180" />
          </button>
          <div className="flex-1 text-center">
            <p className="text-xs font-medium text-gold tracking-widest uppercase">X Marketer AI</p>
            <h1 className="font-display text-xl font-bold text-foreground">Daily Drafts</h1>
          </div>
          <button className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
            <MoreHorizontal className="w-5 h-5 text-foreground" />
          </button>
        </div>
        <p className="text-center text-sm text-muted-foreground italic">
          Hand-crafted by AI for your 2024 growth strategy.
        </p>
      </div>

      {/* Tabs */}
      <div className="px-5">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-3 bg-secondary/50 p-1 rounded-xl">
            <TabsTrigger 
              value="tweets" 
              className="rounded-lg text-xs font-semibold data-[state=active]:bg-gold data-[state=active]:text-navy"
            >
              TWEET IDEAS
            </TabsTrigger>
            <TabsTrigger 
              value="threads"
              className="rounded-lg text-xs font-semibold data-[state=active]:bg-gold data-[state=active]:text-navy"
            >
              THREADS
            </TabsTrigger>
            <TabsTrigger 
              value="strategy"
              className="rounded-lg text-xs font-semibold data-[state=active]:bg-gold data-[state=active]:text-navy"
            >
              STRATEGY
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="tweets" className="mt-4 space-y-3">
            {drafts.filter(d => d.type === 'tweet').map((draft, i) => (
              <motion.div
                key={draft.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <GlassCard className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-gold flex items-center justify-center">
                      <Sparkles className="w-5 h-5 text-navy" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-bold text-gold tracking-wide">{draft.tag}</p>
                      <p className="text-xs text-muted-foreground">Generated {draft.generatedAt}</p>
                    </div>
                  </div>
                  <h3 className="font-display text-lg font-bold text-foreground mb-2">{draft.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">{draft.content}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="flex -space-x-1">
                        <div className="w-6 h-6 rounded-full bg-azure/30 border-2 border-background" />
                        <div className="w-6 h-6 rounded-full bg-gold/30 border-2 border-background" />
                      </div>
                      <span className="text-xs text-muted-foreground">{draft.engagement}% match</span>
                    </div>
                    <button className="btn-gold py-2 px-4 text-xs">
                      Edit Draft
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </TabsContent>
          
          <TabsContent value="threads" className="mt-4 space-y-3">
            {drafts.filter(d => d.type === 'thread').map((draft, i) => (
              <motion.div
                key={draft.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <GlassCard className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-azure/20 flex items-center justify-center">
                      <MessageCircle className="w-5 h-5 text-azure" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-bold text-azure tracking-wide">{draft.tag}</p>
                      <p className="text-xs text-muted-foreground">Generated {draft.generatedAt}</p>
                    </div>
                  </div>
                  <h3 className="font-display text-lg font-bold text-foreground mb-2">{draft.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">{draft.content}</p>
                  <button className="btn-outline-gold w-full py-2 text-xs">
                    View Full Thread
                  </button>
                </GlassCard>
              </motion.div>
            ))}
          </TabsContent>
          
          <TabsContent value="strategy" className="mt-4">
            <GlassCard premium className="p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-gold flex items-center justify-center">
                  <Lightbulb className="w-6 h-6 text-navy" />
                </div>
                <div>
                  <p className="text-xs font-bold text-gold tracking-widest uppercase">Actionable Growth Tip</p>
                  <p className="text-xs text-muted-foreground">Updated daily at 9:00 AM</p>
                </div>
              </div>
              <blockquote className="font-display text-lg italic text-foreground leading-relaxed border-l-2 border-gold pl-4">
                "Focus on the first 3 lines of your tweet. If the hook doesn't stop the scroll, the rest of the content doesn't exist."
              </blockquote>
              <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Tip #47 of 365</span>
                <button className="flex items-center gap-1 text-xs text-gold font-medium">
                  <Bookmark className="w-4 h-4" />
                  Save
                </button>
              </div>
            </GlassCard>
          </TabsContent>
        </Tabs>
      </div>
    </motion.div>
  );
};

const ScheduleScreen = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-6 pb-24"
    >
      {/* Header */}
      <div className="px-5 pt-4">
        <div className="flex items-center gap-3 mb-2">
          <button className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
            <ChevronRight className="w-5 h-5 text-foreground rotate-180" />
          </button>
          <div className="flex-1 text-center">
            <p className="text-xs font-medium text-gold tracking-widest uppercase">X Marketer AI</p>
            <h1 className="font-display text-xl font-bold text-foreground">Schedule</h1>
          </div>
          <button className="w-10 h-10 rounded-xl bg-azure/20 flex items-center justify-center">
            <Calendar className="w-5 h-5 text-azure" />
          </button>
        </div>
      </div>

      {/* Peak Engagement Time */}
      <div className="px-5">
        <div className="text-center mb-6">
          <p className="text-xs font-bold text-azure tracking-widest uppercase mb-2">Peak Engagement</p>
          <h2 className="font-display text-hero text-foreground">09:42</h2>
          <p className="text-lg text-muted-foreground font-medium">AM</p>
        </div>
        
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-azure/10 border border-azure/20">
            <TrendingUp className="w-4 h-4 text-azure" />
            <span className="text-sm font-semibold text-azure">98% Predicted Reach Intensity</span>
          </div>
        </div>
      </div>

      {/* Engagement Chart */}
      <div className="px-5">
        <GlassCard className="p-4">
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={engagementData}>
                <Bar 
                  dataKey="value" 
                  fill="hsl(220 80% 55%)" 
                  radius={[4, 4, 0, 0]}
                  opacity={0.8}
                />
                <XAxis 
                  dataKey="time" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'hsl(220 10% 55%)', fontSize: 10 }}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>
      </div>

      {/* Upcoming Queue */}
      <div className="px-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">Upcoming Queue</h3>
          <button className="text-xs text-azure font-medium">View All</button>
        </div>
        <div className="space-y-3">
          {scheduledPosts.map((post, i) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <GlassCard className="p-4 flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${post.type === 'tweet' ? 'bg-azure/20' : 'bg-gold/20'}`}>
                  {post.type === 'tweet' ? <Edit3 className="w-5 h-5 text-azure" /> : <MessageCircle className="w-5 h-5 text-gold" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">"{post.content}"</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{post.scheduledTime}</p>
                </div>
                <button className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center">
                  <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                </button>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

const AnalyticsScreen = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-6 pb-24"
    >
      {/* Header */}
      <div className="px-5 pt-4">
        <div className="flex items-center gap-3 mb-4">
          <button className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
            <ChevronRight className="w-5 h-5 text-foreground rotate-180" />
          </button>
          <div className="flex-1 text-center">
            <p className="text-xs font-medium text-muted-foreground tracking-widest uppercase">Analysis</p>
          </div>
          <button className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
            <MoreHorizontal className="w-5 h-5 text-foreground" />
          </button>
        </div>
        <p className="text-xs font-bold text-azure tracking-widest uppercase">X Marketer AI</p>
        <h1 className="font-display text-jumbo font-bold text-foreground mt-1">Viral Patterns.</h1>
        
        <div className="flex gap-2 mt-4">
          <span className="px-3 py-1.5 rounded-full bg-secondary text-xs font-medium text-foreground">#AI_GEN</span>
          <span className="px-3 py-1.5 rounded-full bg-azure/20 text-xs font-medium text-azure">HIGH VELOCITY</span>
          <span className="px-3 py-1.5 rounded-full bg-secondary text-xs font-medium text-foreground">GLOBAL</span>
        </div>
      </div>

      {/* Stats */}
      <div className="px-5 space-y-4">
        <GlassCard className="p-5">
          <p className="text-xs font-bold text-muted-foreground tracking-widest uppercase mb-2">Engagement Growth</p>
          <div className="flex items-end gap-3">
            <h2 className="font-display text-mega font-bold text-gradient-gold">+412%</h2>
            <TrendingUp className="w-6 h-6 text-emerald-400 mb-2" />
          </div>
        </GlassCard>
        
        <GlassCard className="p-5">
          <p className="text-xs font-bold text-muted-foreground tracking-widest uppercase mb-2">Viral Velocity</p>
          <div className="flex items-end gap-3">
            <h2 className="font-display text-mega font-bold text-gradient-blue">+89%</h2>
            <TrendingUp className="w-6 h-6 text-emerald-400 mb-2" />
          </div>
        </GlassCard>
      </div>

      {/* Trend Trajectory Chart */}
      <div className="px-5">
        <GlassCard premium className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-xs font-bold text-muted-foreground tracking-widest uppercase">Trend Trajectory</p>
              <h3 className="font-display text-2xl font-bold text-foreground mt-1">2.4M</h3>
              <p className="text-xs text-emerald-400 flex items-center gap-1 mt-0.5">
                <TrendingUp className="w-3 h-3" /> +24% vs Last 24h
              </p>
            </div>
            <StatusBadge>LIVE</StatusBadge>
          </div>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={viralData}>
                <defs>
                  <linearGradient id="viralGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(220 80% 55%)" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="hsl(220 80% 55%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="hsl(220 80% 55%)" 
                  strokeWidth={2}
                  fill="url(#viralGradient)"
                />
                <XAxis 
                  dataKey="time" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'hsl(220 10% 55%)', fontSize: 10 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>
      </div>

      {/* Strategic Insight */}
      <div className="px-5">
        <p className="text-xs font-bold text-muted-foreground tracking-widest uppercase mb-3">Strategic Insight</p>
        <GlassCard className="p-5">
          <blockquote className="font-display text-lg italic text-foreground leading-relaxed">
            "Peak virality is projected at <span className="text-gold font-bold not-italic">19:45 EST</span>. Engagement signals favor long-form threads with technical visual components."
          </blockquote>
        </GlassCard>
      </div>

      {/* Trending Topics */}
      <div className="px-5">
        <p className="text-xs font-bold text-muted-foreground tracking-widest uppercase mb-3">Trending Now</p>
        <div className="space-y-2">
          {trends.map((trend, i) => (
            <motion.div
              key={trend.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center justify-between p-3 rounded-xl bg-secondary/50"
            >
              <div className="flex items-center gap-3">
                <span className="text-sm font-bold text-muted-foreground">0{i + 1}</span>
                <span className="text-sm font-medium text-foreground">{trend.name}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground">{trend.volume}</span>
                <span className="text-xs text-emerald-400 flex items-center gap-0.5">
                  <ArrowUpRight className="w-3 h-3" /> {trend.growth}%
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

const SettingsScreen = () => {
  const [notifications, setNotifications] = useState(true);
  const [autoSchedule, setAutoSchedule] = useState(true);
  const timezone = 'Asia/Shanghai';
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-6 pb-24"
    >
      {/* Header */}
      <div className="px-5 pt-4">
        <p className="text-xs font-medium text-gold tracking-widest uppercase">X Marketer AI</p>
        <h1 className="font-display text-2xl font-bold text-foreground mt-0.5">Settings</h1>
      </div>

      {/* Cron Job Settings */}
      <div className="px-5">
        <GlassCard premium className="p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-gold flex items-center justify-center">
              <Clock className="w-6 h-6 text-navy" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-foreground">Daily Automation</h2>
              <p className="text-xs text-muted-foreground">Configure your cron job</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-xl bg-navy-light/50">
              <div>
                <p className="text-sm font-medium text-foreground">Schedule Time</p>
                <p className="text-xs text-muted-foreground">Every day at 9:00 AM</p>
              </div>
              <button className="btn-gold py-2 px-3 text-xs">
                Edit
              </button>
            </div>
            
            <div className="flex items-center justify-between p-3 rounded-xl bg-navy-light/50">
              <div>
                <p className="text-sm font-medium text-foreground">Timezone</p>
                <p className="text-xs text-muted-foreground">{timezone}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
            
            <div className="flex items-center justify-between p-3 rounded-xl bg-navy-light/50">
              <div>
                <p className="text-sm font-medium text-foreground">Timeout</p>
                <p className="text-xs text-muted-foreground">5 minutes</p>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Preferences */}
      <div className="px-5">
        <h3 className="text-sm font-semibold text-foreground mb-3">Preferences</h3>
        <div className="space-y-2">
          <div className="flex items-center justify-between p-4 rounded-xl bg-secondary/50">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-gold" />
              <div>
                <p className="text-sm font-medium text-foreground">Notifications</p>
                <p className="text-xs text-muted-foreground">Get alerts when tasks complete</p>
              </div>
            </div>
            <Switch checked={notifications} onCheckedChange={setNotifications} />
          </div>
          
          <div className="flex items-center justify-between p-4 rounded-xl bg-secondary/50">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-azure" />
              <div>
                <p className="text-sm font-medium text-foreground">Auto-Schedule</p>
                <p className="text-xs text-muted-foreground">Automatically schedule best drafts</p>
              </div>
            </div>
            <Switch checked={autoSchedule} onCheckedChange={setAutoSchedule} />
          </div>
        </div>
      </div>

      {/* Content Preferences */}
      <div className="px-5">
        <h3 className="text-sm font-semibold text-foreground mb-3">Content Preferences</h3>
        <GlassCard className="p-4 space-y-3">
          {[
            { label: 'Tweet Ideas', count: 3, enabled: true },
            { label: 'Thread Drafts', count: 2, enabled: true },
            { label: 'Growth Tips', count: 1, enabled: true },
            { label: 'Trend Analysis', count: 1, enabled: false },
          ].map((item, i) => (
            <div key={i} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full ${item.enabled ? 'bg-emerald-400' : 'bg-muted'}`} />
                <span className={`text-sm ${item.enabled ? 'text-foreground' : 'text-muted-foreground'}`}>
                  {item.label}
                </span>
              </div>
              <span className="text-xs text-muted-foreground">{item.count} per day</span>
            </div>
          ))}
        </GlassCard>
      </div>

      {/* Account */}
      <div className="px-5">
        <h3 className="text-sm font-semibold text-foreground mb-3">Account</h3>
        <div className="space-y-2">
          <button className="w-full flex items-center justify-between p-4 rounded-xl bg-secondary/50">
            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 text-azure" />
              <span className="text-sm font-medium text-foreground">Connected Accounts</span>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </button>
          
          <button className="w-full flex items-center justify-between p-4 rounded-xl bg-secondary/50">
            <div className="flex items-center gap-3">
              <Target className="w-5 h-5 text-gold" />
              <span className="text-sm font-medium text-foreground">Growth Goals</span>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

// Main App Component
function App() {
  const [activeTab, setActiveTab] = useState('home');
  
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'drafts', label: 'Drafts', icon: FileText },
    { id: 'schedule', label: 'Schedule', icon: Calendar },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const renderScreen = () => {
    switch (activeTab) {
      case 'home': return <HomeScreen />;
      case 'drafts': return <DraftsScreen />;
      case 'schedule': return <ScheduleScreen />;
      case 'analytics': return <AnalyticsScreen />;
      case 'settings': return <SettingsScreen />;
      default: return <HomeScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Container */}
      <div className="mobile-container">
        {/* Main Content */}
        <main className="relative min-h-screen safe-top safe-bottom">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {renderScreen()}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 z-50">
          <div className="max-w-md mx-auto">
            <div className="mx-4 mb-4">
              <div className="glass-card rounded-2xl px-2 py-2">
                <div className="flex items-center justify-around relative">
                  {tabs.map((tab) => (
                    <TabButton
                      key={tab.id}
                      icon={tab.icon}
                      label={tab.label}
                      isActive={activeTab === tab.id}
                      onClick={() => setActiveTab(tab.id)}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
